from mt_amino_library import feature

result = feature.run_analysis(data)
print(result)